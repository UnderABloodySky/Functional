cat A-small-practice.in | ghc -e main tic-tac-toe-tomek.hs > file.out
