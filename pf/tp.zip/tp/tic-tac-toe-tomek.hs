import Data.List.Split

data Cell = X | O | D | T

data Case = WX | WO | Draw | Unfinished


parseCases :: String -> [[String]]
parseCases x = let (n:ts) = filter (not . null) (lines x)
               in take (read n) (toGame (parseCase (chunksOf 4 ts)))

-- Acá podemos empezar a parsear a la estructura  [[String]] -> [Tablero] (transforma los diez tableros)
toGame :: [[String]] -> [[String]]
toGame xs = xs

parseCase :: [[String]] -> [[String]]
parseCase [] = []
parseCase (xs:xss) = (generateOdds xs) : parseCase xss

generateOdds :: [String] -> [String]
generateOdds ss = ss ++ (getColumns ss) ++ getDiagonals ss

getColumns :: [String] -> [String]
getColumns ts = map (\n -> getColumn n ts) [0..3]

getColumn :: Int -> [String] -> String
getColumn n = map (\s -> s !! n)

getDiagonals :: [String] -> [String]
getDiagonals (x:y:z:w:[]) =
  ((x !! 0) : (y !! 1) : (z !! 2) : (w !! 3) : "") :
  ((w !! 0) : (z !! 1) : (y !! 2) : (x !! 3) : "") :
  []

-- answer :: [String] -> [String]
-- answer = [""]

main = do
  ts  <- parseCases `fmap` getContents
  flip mapM_ (zip [1..] ts) $ \(i,t) -> do
  putStrLn $ "Case #" ++ show i ++ ": " ++ show t
  return ()



answer' :: [String] -> String
answer' (x:y:z:w:[]) = x ++ y ++ z ++ w


  -- x ++ y ++ z ++ w ++ (getColumns x y z w)
  -- (x:xs) (y:ys) (z:zs) (w:ws)
  -- x ++ y ++ z ++ w ++

  -- ttttToList :: [[String]] -> [String]
  -- ttttToList [] = []
  -- ttttToList (xs:xss) = (parseS xs) : ttttToList xss
  --
  -- tListToStr :: [String] -> String
  -- tListToStr [] = ""
  -- tListToStr (x:xs) = x ++ tListToStr xs

-- getColumns' :: [String] -> Int -> String
-- getColumns' _ 0 = ""
-- getColumns' xs n = (foldr (\xs' ys -> if null xs'
--   then "a  "
--   else head xs' : ys)
--   []
--   xs) ++
--   getColumns (foldr (\(x:xs') ys -> xs' : ys) [] xs) (n-1)
